import argparse,json,subprocess
from pathlib import Path
parser=argparse.ArgumentParser();parser.add_argument('topology');parser.add_argument('phase',choices=['prepare','restart']);parser.add_argument('--kinds',default='text,image,audio,video,mixed');args=parser.parse_args()
root=Path('/tmp/spoolcache-gemma-current-iitfrkyo/source');out=Path('/tmp/spoolcache-gemma-current-iitfrkyo/live')/args.topology;out.mkdir(parents=True,exist_ok=True)
python='/root/projects/xudongcc/spoolcache/.venv/bin/python'
base=['--api','http://127.0.0.1:8000','--model','google/gemma-4-E2B-it']
fixtures=Path('/tmp/spoolcache-gemma-fixtures.GxWRPx')
cases=[('text',[],None,2048),('image',[('image','cats.jpg')],'CATS,DOGS,OTHER',2048),('audio',[('audio','mary_had_lamb.ogg')],'MARY_HAD_A_LITTLE_LAMB,TWINKLE_TWINKLE_LITTLE_STAR,OTHER',2048),('video',[('video','archery.mp4')],'ARCHERY,STREET,OTHER',2048),('mixed',[('video','archery.mp4'),('image','cats.jpg'),('audio','mary_had_lamb.ogg')],'CATS_MARY_ARCHERY,DOGS_SPEECH_STREET,OTHER',2560)]
def reset():
 subprocess.run([python,str(root/'benchmarks/reset_gpu_prefix_cache.py'),'--api','http://127.0.0.1:8000','--multimodal'],check=True,stdout=subprocess.DEVNULL,timeout=60)
def run(kind,media,labels,phase,salt,bypass=False,skip_read=False,skip_write=False):
 nonce='spoolcache-gemma-current-iitfrkyo-'+args.topology+'-'+kind
 if kind=='text':
  cmd=[python,str(root/'benchmarks/bench_prefix_e2e.py'),*base,'--nonce',nonce,'--cache-salt',salt,'--prompt-source-tokens','4128','--target-tokens','4096' if phase=='producer' else '4128','--max-tokens','8']
 else:
  cmd=[python,str(root/'benchmarks/bench_multimodal_prefix_e2e.py'),*base,'--nonce',nonce,'--cache-salt',salt,'--target-span','4096','--alignment','32','--phase',phase,'--labels',labels,'--max-tokens','32']
  for modality,file in media:cmd+=['--media-kind',modality,'--media-file',str(fixtures/file)]
 if bypass or skip_read:cmd+=['--skip-read']
 if bypass or skip_write:cmd+=['--skip-write']
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=300)
 if r.returncode:
  (out/(kind+'-'+phase+'-failure.txt')).write_text(r.stdout+'\n'+r.stderr)
  raise RuntimeError('benchmark failed: '+str(out/(kind+'-'+phase+'-failure.txt')))
 return json.loads(r.stdout)
def save(kind,phase,result):
 (out/(kind+'-'+phase+'.json')).write_text(json.dumps(result,indent=2)+'\n')
 print(args.topology,kind,phase,result['cached_tokens'],result['output_sha256'],flush=True)
for kind,media,labels,expected in cases:
 if kind not in args.kinds.split(','):continue
 salt='spoolcache-gemma-current-iitfrkyo-'+args.topology+'-'+kind
 if args.phase=='prepare':
  controls=[]
  for n in (1,2):
   reset();r=run(kind,media,labels,'consumer',salt+'-control'+str(n),True);save(kind,'control'+str(n),r);assert r['cached_tokens']==0;controls.append(r)
  assert controls[0]['output_sha256']==controls[1]['output_sha256'],('unstable oracle',kind)
  if labels and kind!='mixed' and not (args.topology=='pp2' and kind=='image'):assert controls[0]['output']['content'].strip()==labels.split(',')[0],('semantic oracle',kind,controls[0]['output'])
  reset();r=run(kind,media,labels,'producer',salt);save(kind,'producer',r);assert r['cached_tokens']==0
  reset();r=run(kind,media,labels,'consumer',salt);save(kind,'restore',r)
 else:
  r=run(kind,media,labels,'consumer',salt);save(kind,'post-restart',r)
 control=json.loads((out/(kind+'-control1.json')).read_text());assert r['cached_tokens']==expected,(kind,r['cached_tokens'],expected);assert r['output_sha256']==control['output_sha256'],('restored output',kind)
