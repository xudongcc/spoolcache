import json, os, subprocess, sys
from pathlib import Path
state=json.loads(Path('/tmp/spoolcache-gemma-current-state.json').read_text())
run=Path(state['run']); r=state['release']
env={**os.environ,'SPOOLCACHE_WHEEL':str(run/'wheel'/r['wheel']),'SPOOLCACHE_WHEEL_SHA256':r['wheel_sha256'],'SPOOLCACHE_COMMIT':r['commit'],'SPOOLCACHE_PATH':str(Path('/root/.cache/spoolcache-qualification')/run.name/'pp1')}
raise SystemExit(subprocess.run(['docker','compose','-f',str(Path(state['source'])/'compose.yaml'),*sys.argv[1:]],env=env).returncode)
