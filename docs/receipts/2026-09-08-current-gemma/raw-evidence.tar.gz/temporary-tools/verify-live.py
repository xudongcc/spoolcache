import ast,json,re,subprocess,sys
from pathlib import Path
mode=sys.argv[1];phase=sys.argv[2] if len(sys.argv)>2 else 'post-restart';out=Path('/tmp/spoolcache-gemma-current-iitfrkyo/live')/mode
pp=2 if mode=='pp2' else 1
containers=['spoolcache-gemma-pp2-head','spoolcache-gemma-pp2-worker'] if pp==2 else ['spoolcache-dev-vllm']
def call(rank,command):
 if rank:command=['ssh','-o','BatchMode=yes','10.100.216.2',__import__('shlex').join(command)]
 return subprocess.check_output(command,stderr=subprocess.STDOUT,text=True)
logs=[];identities=[]
for rank,container in enumerate(containers):
 log=re.sub(r'\x1b\[[0-9;]*m','',call(rank,['docker','logs',container]));logs.append(log);(out/f'{phase}-rank{rank}.log').write_text(log)
 line=re.findall(r'spoolcache: rank identity rank='+str(rank)+r' .*',log)[-1];identity=dict(re.findall(r'(\w+)=([^ ]+)',line));identity['rank']=str(rank)
 state=call(rank,['docker','inspect','--format','{{.Id}} {{.Image}} {{.State.Pid}}',container]).strip().split();identity.update({'container_id':state[0],'image_id':state[1],'container_host_pid':int(state[2])})
 ready=re.findall(r'spoolcache: worker ready rank='+str(rank)+r'.*?root=(\S+)',log)[-1];identity['root']=ready
 layouts=re.findall(r'spoolcache: HMA runtime layout profile=\S+ groups=(\[.*?\]) layers=\d+ alignment=\d+ logical_digest=\w+ physical_digest=(\w+)',log)
 matches=[ast.literal_eval(groups) for groups,digest in layouts if identity['hma_layout'].startswith(digest)];assert matches
 identity['groups']=matches[-1];identities.append(identity)
receipts=[]
for kind in ('text','image','audio','video','mixed'):
 sample=json.loads((out/f'{kind}-{phase}.json').read_text());request=sample['request_id'];span=sample['cached_tokens']
 hits=re.findall(r'spoolcache: hit request='+re.escape(request)+r'\S* tokens=(\d+) entry=([0-9a-f]+)',logs[0]);assert hits and {int(s) for s,e in hits}=={span};entry_prefix=hits[-1][1]
 for rank,container in enumerate(containers):
  restores=re.findall(r'spoolcache: restore rank='+str(rank)+r' request='+re.escape(request)+r'\S* tokens=(\d+) entry=([0-9a-f]+)',logs[rank]);assert restores and set(restores)=={(str(span),entry_prefix)},(rank,kind,restores)
  identity=identities[rank];root=identity['root'];groups=identity['groups']
  entry=call(rank,['docker','exec',container,'python3','-c',"from pathlib import Path; import sys; p=list(Path(sys.argv[1]).glob('manifests/*/'+sys.argv[2]+'*.json')); assert len(p)==1,p; print(p[0].stem)",root,entry_prefix]).strip()
  pages=[]
  for g in groups:
   assert g['policy'] in ('full','sliding') and g['running_state_tail_pages']==0 and not g['eagle'] and g['dcp_shards']==1
   pages.append(0 if not g['layers'] else (span if g['policy']=='full' else min(span,g['window']))//g['block'])
  expected={'rank-root':root,'entry-id':entry,'expected-span':span,'expected-deployment-identity-digest':identity['deployment'],'expected-rank-identity-digest':identity['rank_identity'],'expected-physical-rank':rank,'expected-tp-degree':1,'expected-pp-degree':pp,'expected-dcp-degree':1,'expected-pp-rank':rank,'expected-tp-rank':0,'expected-dcp-rank':0,'expected-topology-digest':identity['topology'],'expected-layout-digest':identity['hma_layout'],'expected-groups':len(groups),'expected-layers':sum(g['layers'] for g in groups),'expected-group-layers':','.join(str(g['layers']) for g in groups),'expected-pages':','.join(map(str,pages))}
  command=['docker','exec','-w','/opt/spoolcache',container,'python3','benchmarks/verify_entry_content.py']
  for k,v in expected.items():command+=['--'+k,str(v)]
  verified=json.loads(call(rank,command));receipts.append({'kind':kind,'rank':rank,'expected':expected,'verification':verified});print(mode,kind,rank,verified['status'],flush=True)
(out/f'{phase}-payload-verification.json').write_text(json.dumps(receipts,indent=2)+'\n')
(out/f'{phase}-runtime-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
