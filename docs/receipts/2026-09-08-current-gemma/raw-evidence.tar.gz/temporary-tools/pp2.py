import json, os, subprocess, sys
from pathlib import Path
state=json.loads(Path('/tmp/spoolcache-gemma-current-state.json').read_text());run=Path(state['run'])
env={**os.environ,'SPOOLCACHE_PATH':str(Path('/root/.cache/spoolcache-qualification')/run.name/'pp2')}
raise SystemExit(subprocess.run([str(Path(state['source'])/'scripts/gemma-pp2-dev.sh'),*sys.argv[1:]],env=env).returncode)
