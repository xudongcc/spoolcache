import json,runpy,sys,subprocess,shlex
from pathlib import Path
mode=sys.argv[1];run=Path(__file__).parent
sys.argv=[str(run/'live-cases.py'),mode,'prepare','--kinds','']
helpers=runpy.run_path(str(run/'live-cases.py'))
reset=helpers['reset'];request=helpers['run'];out=helpers['out']
identities=json.loads((out/'restore-runtime-identities.json').read_text())
containers=['spoolcache-dev-vllm'] if mode=='pp1' else ['spoolcache-gemma-pp2-head','spoolcache-gemma-pp2-worker']
def manifests():
    result=[]
    for rank,container in enumerate(containers):
        cmd=['docker','exec',container,'python3','-c',"from pathlib import Path; import json,sys; print(json.dumps(sorted(p.name for p in Path(sys.argv[1]).glob('manifests/*/*.json'))))",identities[rank]['root']]
        if rank:cmd=['ssh','-o','BatchMode=yes','10.100.216.2',shlex.join(cmd)]
        result.append(json.loads(subprocess.check_output(cmd,text=True)))
    return result
rows=[]
def sample(name,phase,salt,expected,**flags):
    reset();r=request('text',[],None,phase,salt,**flags);rows.append({'case':name,'request':r,'flags':flags})
    (out/'request-flags.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(mode,name,r['cached_tokens'],r['output_sha256'],flush=True)
    assert r['cached_tokens']==expected,(name,r['cached_tokens'],expected)
    return r
prefix=run.name+'-'+mode+'-flags-'
before=manifests()
control=sample('cold-control','consumer',prefix+'cold',0,skip_read=True,skip_write=True)
sample('skip-write-producer','producer',prefix+'no-write',0,skip_write=True)
no_write=sample('skip-write-consumer-misses','consumer',prefix+'no-write',0,skip_write=True)
assert manifests()==before,'skip_write changed persistent manifests'
sample('skip-read-producer-stores','producer',prefix+'save',0,skip_read=True)
restored=sample('skip-write-consumer-restores','consumer',prefix+'save',2048,skip_write=True)
before=manifests()
skipped=sample('skip-read-existing-entry','consumer',prefix+'save',0,skip_read=True,skip_write=True)
assert manifests()==before,'read/write skip changed persistent manifests'
for r in (no_write,restored,skipped):assert r['output_sha256']==control['output_sha256'],'flag output diverged'
print(mode,'request controls passed',flush=True)
