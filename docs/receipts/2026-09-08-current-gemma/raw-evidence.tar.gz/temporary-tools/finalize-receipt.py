from pathlib import Path
import hashlib,json,shutil,tarfile
run=Path(__file__).parent
out=Path('/root/projects/xudongcc/spoolcache/docs/receipts/2026-09-08-current-gemma')
fixed=json.loads((run/'fixed-pp2-repro/summary.json').read_text())
assert fixed['status']=='passed'
assert (run/'restoration.json').exists()
state=json.loads(Path('/tmp/spoolcache-gemma-current-state.json').read_text())
for name in ['restoration.json','host-tests-final.log']:
 shutil.copy2(run/name,out/name)
dest=out/'pp2-fixed';dest.mkdir(exist_ok=True)
for path in (run/'fixed-pp2-repro').glob('*.json'):shutil.copy2(path,dest/path.name)
samples=[json.loads(line) for line in (run/'memory-samples.jsonl').read_text().splitlines()]
minima={host:{field:min(s[host][field] for s in samples if isinstance(s.get(host),dict) and field in s[host]) for field in ['MemAvailable','SwapFree']} for host in ['head','worker']}
summary={'status':'qualification-has-unresolved-finding','artifact':state['release'],'image_id':state['image_id'],
 'model':'google/gemma-4-E2B-it','revision':'3e22461f65e89153144f8adb70e3b8c2cc9845a7','runtime':'vLLM 0.28.0',
 'runtime_tests':{'passed':284,'skipped':1,'skip':'No non-prefix scratch spec exposed by this vLLM build'},
 'host_tests':{'passed':288,'skipped':12,'subtests_passed':373},
 'pp1':{'five_inputs':'cold/store/restore/restart output equivalence passed','payloads':'all authenticated','request_flags':'passed','context_limit':16384,'execution':'compiled'},
 'pp2_fixed':{**fixed,'context_limit':8192,'execution':'eager','upstream_partition':'12,23'},
 'pp2_exploratory':{'case':'mixed','cold_output':'DOGS_SPEECH_STREET','restored_output':'OTHER','cached_tokens':2560,'all_rank_payloads':'authenticated','status':'unresolved output difference'},
 'memory_sample_interval_seconds':5,'memory_minimum_bytes':minima,
 'package_source_hashes_still_match':all(hashlib.sha256(Path('/root/projects/xudongcc/spoolcache',p).read_bytes()).hexdigest()==h for p,h in state['source_files'].items()),
 'limitations':['No new release or push','Fixed PP=2 prompt pass does not close exploratory mixed-input output failure','PP=1 used the retained temporary orchestration; the maintained fixed runner executed PP=2','Cold output equivalence is not media-recognition accuracy','No new fault injection, maximum context, or compatibility-model matrix'],
}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Preserve logs and the exact runners, without private environment or model/media bytes.
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for path in sorted(run.glob('*.py')):tar.add(path,arcname='temporary-tools/'+path.name)
 for path in sorted(run.glob('*.log')):tar.add(path,arcname='logs/'+path.name)
 for name in ['live','fixed-pp2-final','fixed-pp2-repro']:
  for path in sorted((run/name).rglob('*.log')):tar.add(path,arcname=name+'/'+str(path.relative_to(run/name)))
 for name in ['memory-samples.jsonl','negative-observations.json']:
  tar.add(run/name,arcname=name)
 for name in ['run_gemma_e2e.py','gemma_e2e_evidence.py','bench_prefix_e2e.py','bench_multimodal_prefix_e2e.py','reset_gpu_prefix_cache.py','verify_entry_content.py']:
  tar.add(Path('/root/projects/xudongcc/spoolcache/benchmarks')/name,arcname='maintained-tools/'+name)
 tar.add(run/'wheel/release.json',arcname='artifact/release.json')
 tar.add(run/'wheel'/state['release']['wheel'],arcname='artifact/'+state['release']['wheel'])
(out/'raw-evidence.sha256').write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  raw-evidence.tar.gz\n')
(out/'README.md').write_text('''# Current-code Gemma regression, 2026-09-08

The overall no-regression qualification has an **unresolved PP=2 mixed-input
output difference**. Do not treat the fixed-fixture pass as resolving it.

| Run | Result |
| --- | --- |
| Installed vLLM 0.28.0/CUDA suite | 284 passed, one skip (no non-prefix scratch spec in this build) |
| Host suite, including fixed-runner failure assertions | 288 passed, 12 skips, 373 subtests passed |
| PP=1, TP=1, compiled, 16K | All five inputs restored before/after restart with matching cold output and authenticated payloads; request controls passed |
| PP=2, TP=1, eager, 8K, partition 12,23 | Maintained fixed runner passed all five inputs, both controls, both-stage payload checks and whole-group restart |
| Earlier PP=2 generated prompt | Mixed cold controls returned `DOGS_SPEECH_STREET` twice; restored output was `OTHER` despite 2,560 cached tokens and authenticated payloads on both stages |

The initial PP=1 mixed semantic-label assertion also failed: both cold controls
returned `OTHER`. That observation is retained in
[negative-observations.json](negative-observations.json); subsequent PP=1 mixed
checks used the explicitly stated cold-output-equivalence contract, not a claim
of correct media classification.

The fixed PP=2 prompt changed the input, not the output assertion. The earlier
failure remains open: no baseline comparison establishes whether it is a new
SpoolCache regression or pre-existing runtime behavior. Its initial generated
nonce was not retained, so the exact prompt cannot be replayed from API rows
alone. The maintained runner now fixes prompt text and retains each command,
run salt, media hash and request/result record. It exits nonzero on a mismatch;
no Agent is required to choose a plan or judge an output.

## Artifact and scope

Model: `google/gemma-4-E2B-it`, immutable revision
`3e22461f65e89153144f8adb70e3b8c2cc9845a7`, official vLLM 0.28.0 on two DGX Spark
hosts. PP=1 uses only the head. Exact image, source and wheel identities are in
[artifact.json](artifact.json) and [release.json](release.json).

The isolated candidate is `0.2.0rc1`, source commit
`eabe045bd4b55188846dc6fe6fa09bbebe06798c`. It was built twice with identical wheel
bytes from a clean committed snapshot of the current working package, with
python-semantic-release stamping the candidate version. The working package
files still match that snapshot apart from the candidate version stamp.
Both hosts used the same immutable installed-wheel image. No serving source
mounts or source PYTHONPATH were used. This was not a PyPI release or remote push.

The current package checks include `O_DIRECT`, path/capacity configuration and
independent `spoolcache.skip_read` / `spoolcache.skip_write`. Text/image/audio/video
restore 2,048 tokens; mixed restores 2,560. Each persistent hit requires matching
API span, scheduler/rank entry agreement, full payload authentication and cold
output equivalence. Wrong media labels in cold controls remain wrong labels;
see [cold-labels.json](cold-labels.json). These results do not establish media
recognition accuracy, new fault recovery, maximum context or throughput gains.

## Evidence

- [Summary](summary.json), [host test log](host-tests-final.log),
  [head installed wheel](installed-wheel.json), [worker installed wheel](worker-installed-wheel.json).
- [PP=1 payloads after restart](pp1/post-restart-payload-verification.json)
  and [request controls](pp1/request-flags.json).
- [PP=2 fixed runner summary](pp2-fixed/summary.json),
  [payloads after restart](pp2-fixed/post-restart-payload-verification.json),
  [request controls](pp2-fixed/request-flags.json).
- [Earlier PP=2 failure](pp2-exploratory-failure/failure.json),
  [interpretation](pp2-exploratory-failure/interpretation.json),
  [authenticated payloads](pp2-exploratory-failure/restore-payload-verification.json).
- [Raw logs, runner snapshots and authenticated candidate wheel](raw-evidence.tar.gz),
  [archive SHA-256](raw-evidence.sha256).
- [Restored lab state](restoration.json).

PP=1 used the retained temporary orchestration; the maintained fixed runner was
executed on PP=2. Its CPU tests reject unstable controls, changed restored output,
invalid counters, missing rank restores, conflicting scheduler entries and
partial group restarts. A preliminary runner was cancelled before requests to
correct a test-only assumption: PP stage deployment identities differ, while
the common topology agrees. No package code changed during the live tests.

The PP=1 container's combined log includes an upstream `EngineDeadError` during
the requested Compose shutdown/restart; the replacement startup and requests
succeeded. The maintained verifier reads logs since each current container start
to distinguish previous shutdown diagnostics from errors in the tested process.

Both hosts initially had no active model services. Test groups were stopped and
the original development image tags restored afterwards. Persistent test roots
under `/root/.cache/spoolcache-qualification/spoolcache-gemma-current-iitfrkyo/`
were retained on their owning hosts; no existing persistent root was deleted.
''')
print(out)
