import json,subprocess,time
from pathlib import Path
state=json.loads(Path('/tmp/spoolcache-mixed-investigation-state.json').read_text());run=Path(state['run'])
while not (run/'stop-monitor').exists():
    row={'unix_time':time.time()}
    for name,cmd in [('head',['cat','/proc/meminfo']),('worker',['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','10.100.216.2','cat /proc/meminfo'])]:
        try:
            raw=subprocess.check_output(cmd,text=True,timeout=10)
            row[name]={line.split(':')[0]:int(line.split()[1])*1024 for line in raw.splitlines() if line.split(':')[0] in ('MemAvailable','SwapFree')}
        except Exception as error: row[name]={'error':type(error).__name__}
    with (run/'memory-samples.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    time.sleep(5)
