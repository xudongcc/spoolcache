from pathlib import Path
exec((Path(__file__).parent/'probe.py').read_text().split('summaries=[]')[0])
src=R/'variant-12';out=R/'encoder-control';out.mkdir(exist_ok=True)
producer=json.loads((src/'producer-request.json').read_text());consumer=json.loads((src/'cold1-request.json').read_text());salt=R.name+'-encoder-control'
rows={}
for name in ['cold1','cold2']:
 reset();rows[name]=request(out,name,consumer,salt+'-'+name,False,False)
reset();rows['producer']=request(out,'producer',producer,salt)
reset_gpu_prefix_cache(API);rows['restore-encoder-retained']=request(out,'restore-encoder-retained',consumer,salt,True,False)
reset();rows['restore-encoder-reset']=request(out,'restore-encoder-reset',consumer,salt,True,False)
reset();rows['cold-prime']=request(out,'cold-prime',consumer,salt+'-cold-prime',False,False)
reset_gpu_prefix_cache(API);rows['restore-after-cold-prime']=request(out,'restore-after-cold-prime',consumer,salt,True,False)
reset();rows['restore-reset-again']=request(out,'restore-reset-again',consumer,salt,True,False)
write(out/'summary.json',rows)
