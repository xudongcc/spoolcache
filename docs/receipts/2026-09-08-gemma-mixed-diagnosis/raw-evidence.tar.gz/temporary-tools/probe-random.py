import sys,json,time,copy,hashlib,urllib.request
from pathlib import Path
sys.path.insert(0,'/root/projects/xudongcc/spoolcache')
from benchmarks import bench_multimodal_prefix_e2e as b
from benchmarks.reset_gpu_prefix_cache import reset_gpu_prefix_cache,reset_multimodal_caches
from benchmarks.run_gemma_e2e import MEDIA,MODEL
R=Path(__file__).parent;API='http://127.0.0.1:8000';F=Path('/tmp/spoolcache-gemma-fixtures.GxWRPx');LABELS='CATS_MARY_ARCHERY,DOGS_SPEECH_STREET,OTHER'
for _ in range(180):
 try:
  with urllib.request.urlopen(API+'/health',timeout=3) as r:
   if r.status==200:break
 except Exception:pass
 time.sleep(5)
else:raise RuntimeError('startup timeout')
parts=[]
for kind,name in [('video','archery.mp4'),('image','cats.jpg'),('audio','mary_had_lamb.ogg')]:
 data=(F/name).read_bytes();assert (len(data),hashlib.sha256(data).hexdigest())==MEDIA[name]
 url,mime,_=b._data_url(kind,F/name);parts.append(b._media_part(kind,url,mime))
def reset():reset_gpu_prefix_cache(API);reset_multimodal_caches(API)
def write(path,v):path.write_text(json.dumps(v,indent=2)+'\n')
def request(out,label,body,salt,read=True,write_cache=True):
 body=copy.deepcopy(body);body['cache_salt']=salt
 body['kv_transfer_params']={'spoolcache.skip_read':not read,'spoolcache.skip_write':not write_cache}
 body['logprobs']=True;body['top_logprobs']=5
 write(out/(label+'-request.json'),body)
 response=b._post_json(API,'/v1/chat/completions',body)
 write(out/(label+'-response.json'),response)
 normalized=b._normalized_output(response);b._validate_content_oracle(normalized,LABELS)
 cached=response['usage']['prompt_tokens_details']['cached_tokens'];assert type(cached)is int
 row={'case':label,'cached_tokens':cached,'prompt_tokens':response['usage']['prompt_tokens'],'output':normalized,'request_id':response['id'],'output_sha256':hashlib.sha256(json.dumps(normalized,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
 write(out/(label+'.json'),row);print(out.name,label,cached,normalized['content'],flush=True);return row
summaries=[]
for i in range(6, 14):
 out=R/('variant-'+str(i));out.mkdir(exist_ok=True);nonce=hashlib.sha256(('spoolcache-repro-'+str(i)).encode()).hexdigest()[:32]+'-mixed';salt=R.name+'-'+str(i)
 def body(n,p,phase='producer'):
  return b._request_body(model=MODEL,media_part=parts,nonce=nonce,repetitions=n,padding=p,labels=LABELS,cache_salt=salt,skip_write=False,phase=phase,max_tokens=32)
 n,p,producer_tokens=b._calibrate_exact_prompt(API,body,4096)
 producer=body(n,p);consumer=body(n,p,'consumer');ct=b._token_ids(API,consumer);assert ct[:4096]==producer_tokens
 write(out/'input.json',{'nonce':nonce,'salt':salt,'repetitions':n,'padding':p,'producer_tokens':producer_tokens,'consumer_tokens':ct,'media':MEDIA})
 rows={}
 for label in ['cold1','cold2']:
  reset();rows[label]=request(out,label,consumer,salt+'-'+label,False,False);assert rows[label]['cached_tokens']==0
 reset();rows['producer']=request(out,'producer',producer,salt)
 assert rows['producer']['cached_tokens']==0
 for label in ['restore1','restore2']:
  reset();rows[label]=request(out,label,consumer,salt,True,False)
 reset();rows['cold3']=request(out,'cold3',consumer,salt,False,False)
 reset();rows['gpu-producer']=request(out,'gpu-producer',producer,salt+'-gpu',False,False)
 reset_multimodal_caches(API)
 rows['gpu-restore']=request(out,'gpu-restore',consumer,salt+'-gpu',False,False)
 summary={'variant':i,'nonce':nonce,'rows':rows,'cold_stable':len({rows[x]['output_sha256'] for x in ['cold1','cold2','cold3']})==1,'restore_matches_cold':rows['restore1']['output_sha256']==rows['cold1']['output_sha256'],'gpu_matches_cold':rows['gpu-restore']['output_sha256']==rows['cold1']['output_sha256']}
 summaries.append(summary);write(R/'probe-random-summary.json',summaries)
 if summary['cold_stable'] and not summary['restore_matches_cold']:
  print('REPRODUCED',i,flush=True);break
