from pathlib import Path
exec((Path(__file__).parent/'probe.py').read_text().split('summaries=[]')[0])
variants=json.loads((R/'probe-random-summary.json').read_text())
selected=next((v for v in variants if v['cold_stable'] and not v['restore_matches_cold']),variants[0]);i=selected['variant'];src=R/((('invariant-' if len(sys.argv)>1 and sys.argv[1]=='invariant' else '')+'variant-')+str(i));out=src/'native-media-boundary';out.mkdir(exist_ok=True)
producer=json.loads((src/'producer-request.json').read_text());consumer=json.loads((src/'cold1-request.json').read_text());ct=json.loads((src/'input.json').read_text())['consumer_tokens'];short=copy.deepcopy(producer)
short['messages'][0]['content']=short['messages'][0]['content'][:2]
short['max_tokens']=1
ids=b._token_ids(API,short)
common=next((j for j,(a,c) in enumerate(zip(ids,ct)) if a!=c),min(len(ids),len(ct)))
assert 2560<=common<2592,(common,len(ids))
lo=None
write(out/'input.json',{'variant':i,'text_cut':lo,'common_prefix_tokens':common,'short_producer_tokens':ids,'consumer_tokens':ct})
rows={}
for n in (1,2,3):
 salt=R.name+'-partial-'+str(i)+'-'+str(n);reset()
 # A one-token producer can end before the full constrained label; retain raw evidence.
 body=copy.deepcopy(short);body['cache_salt']=salt;body['kv_transfer_params']={'spoolcache.skip_read':True,'spoolcache.skip_write':True};write(out/f'producer{n}-request.json',body)
 response=b._post_json(API,'/v1/chat/completions',body);write(out/f'producer{n}-response.json',response);assert response['usage']['prompt_tokens_details']['cached_tokens']==0
 reset_multimodal_caches(API);row=request(out,'native'+str(n),consumer,salt,False,False);assert row['cached_tokens']==2560,row
 rows['native'+str(n)]=row
reset();rows['cold']=request(out,'cold',consumer,R.name+'-partial-cold',False,False)
reset();rows['spoolcache']=request(out,'spoolcache',consumer,json.loads((src/'input.json').read_text())['salt'],True,False)
write(out/'summary.json',rows)
