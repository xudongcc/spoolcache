# Narrow release-qualification mutation/recovery; never remove a cache root.
import dataclasses,fcntl,hashlib,json,os,shutil,stat,sys,uuid
from pathlib import Path
from spoolcache.manifest import decode_manifest
mode=sys.argv[1]
def syncdir(path):
 fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def authenticate(path,descriptor):
 st=path.lstat();assert stat.S_ISREG(st.st_mode) and st.st_size==descriptor['stored_length']
 digest=hashlib.sha256();remaining=descriptor['byte_length']
 with path.open('rb') as src:
  while data:=src.read(1024*1024):
   logical=min(remaining,len(data));digest.update(data[:logical]);remaining-=logical;assert not any(data[logical:])
 assert remaining==0 and digest.hexdigest()==descriptor['sha256']
if mode=='inject':
 expected=json.loads(sys.argv[2]);root=Path(expected['rank-root']);entry=expected['entry-id']
 manifest_path=root/'manifests'/entry[:2]/(entry+'.json');envelope=decode_manifest(manifest_path.read_bytes());m=envelope.manifest
 assert m.entry_id==entry and m.rank_identity_digest==expected['expected-rank-identity-digest'] and m.deployment_identity_digest==expected['expected-deployment-identity-digest'] and m.span_tokens==expected['expected-span']
 # Count references before selecting a single uniquely owned descriptor.
 references={d.relative_path:0 for d in m.objects}
 for candidate in root.glob('manifests/*/*.json'):
  for d in decode_manifest(candidate.read_bytes()).manifest.objects:
   if d.relative_path in references:references[d.relative_path]+=1
 descriptor=next(d for d in m.objects if references[d.relative_path]==1)
 d=dataclasses.asdict(descriptor);target=root/descriptor.relative_path
 lock=os.open(root/'state/maintenance.lock',os.O_RDWR|os.O_NOFOLLOW)
 with os.fdopen(lock,'rb') as lockfile:
  fcntl.flock(lockfile,fcntl.LOCK_EX);authenticate(target,d)
  backup=Path('/var/lib/spoolcache/.g6-qualification-backups')/uuid.uuid4().hex;backup.mkdir(parents=True,mode=0o700)
  for src,dst in ((target,backup/'object'),(manifest_path,backup/'manifest')):
   with src.open('rb') as inp,dst.open('xb') as out:
    shutil.copyfileobj(inp,out,1024*1024);out.flush();os.fsync(out.fileno())
  authenticate(backup/'object',d)
  receipt={'schema':'spoolcache-release-fault-backup/v1','backup':str(backup),'target':str(target),'descriptor':d,'expected':expected,'mutation':'xor first byte with 1','shared_references':1}
  with (backup/'receipt.json').open('x') as out:
   json.dump(receipt,out);out.flush();os.fsync(out.fileno())
  syncdir(backup);syncdir(backup.parent);syncdir(backup.parent.parent)
  fd=os.open(target,os.O_RDWR|os.O_NOFOLLOW)
  try:
   first=os.pread(fd,1,0);assert len(first)==1;os.pwrite(fd,bytes([first[0]^1]),0);os.fsync(fd)
  finally:os.close(fd)
 print(json.dumps(receipt))
elif mode=='restore':
 backup=Path(sys.argv[2]);receipt=json.loads((backup/'receipt.json').read_text());target=Path(receipt['target']);d=receipt['descriptor'];authenticate(backup/'object',d)
 # Caller must prove every old rank stopped before recovery.
 temporary=target.with_name(target.name+'.g6-'+uuid.uuid4().hex)
 with (backup/'object').open('rb') as inp,temporary.open('xb') as out:
  shutil.copyfileobj(inp,out,1024*1024);out.flush();os.fsync(out.fileno())
 os.replace(temporary,target);syncdir(target.parent);authenticate(target,d)
 print(json.dumps({'status':'restored-and-authenticated','target':str(target),'sha256':d['sha256']}))
elif mode=='cleanup':
 backup=Path(sys.argv[2]);assert backup.parent==Path('/var/lib/spoolcache/.g6-qualification-backups') and len(backup.name)==32 and all(c in '0123456789abcdef' for c in backup.name)
 receipt=json.loads((backup/'receipt.json').read_text());authenticate(Path(receipt['target']),receipt['descriptor']);authenticate(backup/'object',receipt['descriptor'])
 expected=receipt['expected'];manifest=Path(expected['rank-root'])/'manifests'/expected['entry-id'][:2]/(expected['entry-id']+'.json');assert manifest.read_bytes()==(backup/'manifest').read_bytes()
 shutil.rmtree(backup);syncdir(backup.parent)
 print(json.dumps({'status':'authenticated-temporary-backup-removed','backup':str(backup)}))
else:raise ValueError(mode)
