import json,os,subprocess,sys
from pathlib import Path
r=json.loads(Path('dist/release/release.json').read_text())
env={**os.environ,'SPOOLCACHE_WHEEL':'dist/release/'+r['wheel'],'SPOOLCACHE_WHEEL_SHA256':r['wheel_sha256'],'SPOOLCACHE_COMMIT':r['commit']}
raise SystemExit(subprocess.run(['docker','compose',*sys.argv[1:]],env=env).returncode)
