import json,re,shlex,subprocess,sys,time,urllib.request
from pathlib import Path
mode=sys.argv[1];pp=2 if mode=='pp2' else 1;rank=pp-1;out=Path('/tmp/g6-live')/mode
containers=['spoolcache-gemma-pp2-head','spoolcache-gemma-pp2-worker'] if pp==2 else ['spoolcache-dev-vllm'];container=containers[rank]
root=Path('/root/projects/xudongcc/spoolcache');python='/tmp/g6-install-1-cssb6v0t/bin/python'
script=Path('/tmp/g6-fault-object.py').read_text()
def call(r,cmd,input=None,check=True):
 if r:cmd=['ssh','-o','BatchMode=yes','10.100.216.2',shlex.join(cmd)]
 return subprocess.run(cmd,input=input,capture_output=True,text=True,check=check,timeout=120)
def health():
 try:urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=2).read();return True
 except Exception:return False
subprocess.run([python,str(root/'benchmarks/reset_gpu_prefix_cache.py'),'--api','http://127.0.0.1:8000','--multimodal'],check=True,stdout=subprocess.DEVNULL)
metrics=urllib.request.urlopen('http://127.0.0.1:8000/metrics',timeout=10).read().decode();(out/'pre-fault-metrics.prom').write_text(metrics)
assert all(re.search(r'spoolcache_readiness\{[^\n]*condition="'+condition+r'"[^\n]*\} 1(?:\.0)?\n',metrics) for condition in ('rank_identity','inventory_quorum','fatal_clear'))
expected=next(r['expected'] for r in json.loads((out/'post-restart-payload-verification.json').read_text()) if r['kind']=='text' and r['rank']==rank)
state=json.loads(call(rank,['docker','inspect',container]).stdout)[0];mount=next(m for m in state['Mounts'] if m['Destination']=='/var/lib/spoolcache');image=state['Image'];source=mount['Name'] if mount['Type']=='volume' else mount['Source']
# Observe the actual worker exit syscall externally; vLLM logs may omit it.
processes=call(rank,['docker','top',container,'-eo','pid,comm']).stdout.splitlines()[1:]
needle='Worker' if pp==2 else 'EngineCor'
candidates=[line.split()[0] for line in processes if needle in line]
assert len(candidates)==1,processes
trace_path='/tmp/g6-'+mode+'-worker-exit.strace'
trace_cmd=['strace','-e','trace=exit_group','-p',candidates[0],'-o',trace_path]
if rank:trace_cmd=['ssh','-o','BatchMode=yes','10.100.216.2',shlex.join(trace_cmd)]
trace_stderr=(out/'fault-strace.stderr').open('w')
tracer=subprocess.Popen(trace_cmd,stdout=subprocess.DEVNULL,stderr=trace_stderr)
time.sleep(1)
assert tracer.poll() is None,'could not attach worker exit observer'
backup=json.loads(call(rank,['docker','exec','-i',container,'python3','-','inject',json.dumps(expected)],input=script).stdout);(out/'fault-backup.json').write_text(json.dumps(backup,indent=2)+'\n')
result=None;logs=[];readiness_false=False;head_health_before_group_stop=None;client=None
try:
 nonce='g6-release-'+mode+'-text';command=[python,str(root/'benchmarks/bench_prefix_e2e.py'),'--api','http://127.0.0.1:8000','--model','google/gemma-4-E2B-it','--nonce',nonce,'--cache-salt',nonce,'--prompt-source-tokens','4128','--target-tokens','4128','--max-tokens','8']
 client=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 tracer.wait(timeout=45)
 head_health_before_group_stop=health()
 for r,c in enumerate(containers):
  log=call(r,['docker','logs',c],check=False);content=log.stdout+log.stderr;logs.append(content);(out/f'fault-rank{r}.log').write_text(content)

finally:
 stop=['bash',str(root/'scripts/gemma-pp2-dev.sh'),'stop'] if pp==2 else ['python3','/tmp/g6-compose.py','stop','vllm']
 subprocess.run(stop,check=True)
 readiness_false=not health()
 if client is not None:
  stdout,stderr=client.communicate(timeout=15)
  result=subprocess.CompletedProcess(command,client.returncode,stdout,stderr)
  (out/'fault-client.stdout').write_text(stdout);(out/'fault-client.stderr').write_text(stderr)
 states=[]
 for r,c in enumerate(containers):
  st=call(r,['docker','inspect','--format','{{.State.Running}}',c],check=False);assert st.returncode!=0 or st.stdout.strip()=='false';states.append('stopped')
 recovered=json.loads(call(rank,['docker','run','--rm','-i','-v',source+':/var/lib/spoolcache','--entrypoint','python3',image,'-','restore',backup['backup']],input=script).stdout)
 (out/'fault-object-recovery.json').write_text(json.dumps(recovered,indent=2)+'\n')
assert result is not None and result.returncode!=0,'client incorrectly accepted corrupted restore'
assert readiness_false,'API remained healthy after fatal restore'
assert 'post-admission restore failed; terminating worker' in logs[rank]
tracer.wait(timeout=15);trace_stderr.close()
trace=call(rank,['cat',trace_path]).stdout;(out/'worker-exit.strace').write_text(trace)
assert 'exit_group(70)' in trace,'missing observed worker exit 70'
receipt={'status':'passed','client_rejected':True,'head_health_before_deployment_stop':head_health_before_group_stop,'stop_trigger':'observed worker exit; external deployment-owned full-group stop','api_readiness_observation':'after complete group stop','api_readiness_false':True,'all_ranks_stopped':states,'worker_exit_code':70,'corrupted_rank':rank,'entry_id':expected['entry-id'],'expected_span':expected['expected-span'],'object_recovery':recovered}
(out/'post-admission-fault.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
